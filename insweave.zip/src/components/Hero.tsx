import { ArrowRight, Award } from 'lucide-react';

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 leading-tight mb-6">
            Digital Infrastructure For{' '}
            <span className="text-blue-600">Modern Enterprises</span>
          </h1>
          <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
            Comprehensive technology solutions, business services, and digital transformation
            expertise. From web development to legal compliance, we provide end-to-end support
            for your enterprise growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={() => scrollToSection('services')}
              className="group bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-all flex items-center gap-2 text-lg font-medium shadow-lg hover:shadow-xl"
            >
              Explore Services
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => scrollToSection('portfolio')}
              className="group bg-white text-blue-600 px-8 py-4 rounded-lg hover:bg-gray-50 transition-all flex items-center gap-2 text-lg font-medium border-2 border-blue-600"
            >
              <Award className="h-5 w-5" />
              View Certifications
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
