interface PortfolioItemProps {
  title: string;
  description: string;
  techStack: string[];
}

function PortfolioItem({ title, description, techStack }: PortfolioItemProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-300 group">
      <div className="h-48 bg-gradient-to-br from-blue-500 to-blue-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity" />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <div className="flex flex-wrap gap-2">
          {techStack.map((tech, index) => (
            <span
              key={index}
              className="px-3 py-1 bg-blue-50 text-blue-700 text-sm rounded-full border border-blue-200"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function Portfolio() {
  const projects = [
    {
      title: 'e-Commerce Platform',
      description: 'Full-featured online shopping platform with payment integration and inventory management',
      techStack: ['React', 'Node.js', 'PostgreSQL', 'Stripe'],
    },
    {
      title: 'Mobile Banking App',
      description: 'Secure mobile banking solution with real-time transactions and biometric authentication',
      techStack: ['React Native', 'Firebase', 'AWS', 'Security'],
    },
    {
      title: 'SaaS Dashboard',
      description: 'Analytics and management dashboard for enterprise resource planning',
      techStack: ['Vue.js', 'Python', 'MongoDB', 'Docker'],
    },
    {
      title: 'Healthcare Portal',
      description: 'Patient management system with appointment scheduling and telemedicine features',
      techStack: ['Angular', 'Java', 'MySQL', 'HIPAA'],
    },
  ];

  return (
    <section id="portfolio" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Our Portfolio
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore our successful project implementations across various industries
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <PortfolioItem
              key={index}
              title={project.title}
              description={project.description}
              techStack={project.techStack}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
