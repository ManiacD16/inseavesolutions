import {
  Globe,
  Code,
  Smartphone,
  Palette,
  Shield,
  ShoppingCart,
  Server,
  Layers,
  Wrench,
  Calculator,
  FileText,
  Briefcase,
  DollarSign,
  Scale,
  Building,
} from 'lucide-react';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
}

function ServiceCard({ icon, title }: ServiceCardProps) {
  return (
    <div className="bg-white p-6 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all duration-300 group">
      <div className="flex flex-col items-center text-center">
        <div className="mb-4 text-blue-600 group-hover:scale-110 transition-transform">
          {icon}
        </div>
        <h3 className="text-gray-900 font-medium">{title}</h3>
      </div>
    </div>
  );
}

export default function Services() {
  const technologyServices = [
    { icon: <Globe className="h-8 w-8" />, title: 'Domain Hosting' },
    { icon: <Code className="h-8 w-8" />, title: 'Web Development' },
    { icon: <Smartphone className="h-8 w-8" />, title: 'App Creation' },
    { icon: <Palette className="h-8 w-8" />, title: 'Website Design' },
    { icon: <Shield className="h-8 w-8" />, title: 'Security Repair' },
    { icon: <ShoppingCart className="h-8 w-8" />, title: 'E-Commerce Solutions' },
    { icon: <Server className="h-8 w-8" />, title: 'Server Management' },
    { icon: <Layers className="h-8 w-8" />, title: 'Graphic Design' },
    { icon: <Wrench className="h-8 w-8" />, title: 'Custom Development' },
  ];

  const businessServices = [
    { icon: <Calculator className="h-8 w-8" />, title: 'Accounting Services' },
    { icon: <FileText className="h-8 w-8" />, title: 'Trademark Registration' },
    { icon: <Briefcase className="h-8 w-8" />, title: 'Tax Services' },
    { icon: <Building className="h-8 w-8" />, title: 'Government Filings' },
    { icon: <DollarSign className="h-8 w-8" />, title: 'Loan Assistance' },
    { icon: <Scale className="h-8 w-8" />, title: 'Compliance Solutions' },
  ];

  return (
    <section id="services" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-4">
            Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive solutions tailored for your business needs
          </p>
        </div>

        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">
            Technology & Digital
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {technologyServices.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
              />
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-bold text-gray-900 mb-8">
            Business, Legal & Financial
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {businessServices.map((service, index) => (
              <ServiceCard
                key={index}
                icon={service.icon}
                title={service.title}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
